package com.deskbrowser.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.view.View
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.webkit.WebViewAssetLoader
import org.json.JSONArray
import org.json.JSONObject

/**
 * الهيكل:
 *  - shell: WebView واحد يعرض واجهة دسك براوزر (assets/index.html): الشريط العلوي وشريط المهام والقوائم.
 *  - tab views: WebView حقيقي لكل تبويب، يوضع فوق منطقة الشاشة (stage) بإحداثيات ترسلها الواجهة.
 *  - الجسر AndroidBridge: الواجهة تأمر (load/back/show/rect/exts...) والنظام يرد بـ __native.onState.
 */
class MainActivity : AppCompatActivity() {

    companion object {
        const val DESKTOP_UA =
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36"
        const val BASE = "https://appassets.androidplatform.net/assets/index.html"
        const val REQ_FILE = 101
        const val REQ_PERM = 200
    }

    private lateinit var root: FrameLayout
    private lateinit var shell: WebView
    private val views = HashMap<String, WebView>()
    private var activeId = ""
    private var hidden = false
    private var box = floatArrayOf(0f, 0f, 0f, 0f)
    private var isDesk = true
    private var viewportW = 1280
    private var extList = JSONArray()
    private var isFull = false
    private var fileCb: ValueCallback<Array<Uri>>? = null
    private var pendingPerm: PermissionRequest? = null
    private var customView: View? = null
    private var customCb: WebChromeClient.CustomViewCallback? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        root = FrameLayout(this)
        root.layoutDirection = View.LAYOUT_DIRECTION_LTR
        root.setBackgroundColor(Color.parseColor("#0B1220"))
        setContentView(root)

        CookieManager.getInstance().setAcceptCookie(true)

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        shell = WebView(this)
        shell.setBackgroundColor(Color.parseColor("#0B1220"))
        shell.settings.javaScriptEnabled = true
        shell.settings.domStorageEnabled = true
        shell.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                val u = request?.url ?: return null
                return loader.shouldInterceptRequest(u)
            }
        }
        shell.addJavascriptInterface(Bridge(), "AndroidBridge")
        root.addView(shell, FrameLayout.LayoutParams(-1, -1))
        shell.loadUrl(BASE)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (customView != null) {
                    hideCustom()
                    return
                }
                shell.evaluateJavascript("window.__nativeBack&&window.__nativeBack()", null)
            }
        })
    }

    private fun ua(): String = if (isDesk) DESKTOP_UA else WebSettings.getDefaultUserAgent(this)

    // ---------- بناء WebView لكل تبويب ----------
    @SuppressLint("SetJavaScriptEnabled")
    private fun createView(id: String): WebView {
        val w = WebView(this)
        w.setBackgroundColor(Color.WHITE)
        val s = w.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.databaseEnabled = true
        s.mediaPlaybackRequiresUserGesture = false
        s.loadWithOverviewMode = true
        s.useWideViewPort = true
        s.setSupportZoom(true)
        s.builtInZoomControls = true
        s.displayZoomControls = false
        s.javaScriptCanOpenWindowsAutomatically = true
        s.setSupportMultipleWindows(false)
        s.allowFileAccess = false
        s.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        s.userAgentString = ua()
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, true)

        w.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                view?.let { state(id, it, true) }
            }

            override fun onPageCommitVisible(view: WebView?, url: String?) {
                if (view != null && url != null) {
                    if (isDesk) view.evaluateJavascript(vpScript(), null)
                    val c = cssScript(url)
                    if (c.isNotEmpty()) view.evaluateJavascript(c, null)
                }
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                if (view == null || url == null) return
                if (isDesk) view.evaluateJavascript(vpScript(), null)
                val c = cssScript(url)
                if (c.isNotEmpty()) view.evaluateJavascript(c, null)
                runExtJs(view, url)
                state(id, view, false)
            }

            override fun doUpdateVisitedHistory(view: WebView?, url: String?, isReload: Boolean) {
                view?.let { state(id, it, it.progress < 100) }
            }

            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val u = request?.url ?: return false
                val sch = u.scheme ?: ""
                if (sch == "http" || sch == "https" || sch == "about" || sch == "data" || sch == "blob") return false
                if (sch == "file" || sch == "content") return true
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, u))
                } catch (e: Exception) {
                }
                return true
            }
        }

        w.webChromeClient = object : WebChromeClient() {
            override fun onReceivedTitle(view: WebView?, title: String?) {
                view?.let { state(id, it, it.progress < 100) }
            }

            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                fileCb?.onReceiveValue(null)
                fileCb = filePathCallback
                return try {
                    @Suppress("DEPRECATION")
                    startActivityForResult(fileChooserParams!!.createIntent(), REQ_FILE)
                    true
                } catch (e: Exception) {
                    fileCb = null
                    false
                }
            }

            override fun onPermissionRequest(request: PermissionRequest?) {
                if (request == null) return
                runOnUiThread {
                    val need = ArrayList<String>()
                    for (r in request.resources) {
                        if (r == PermissionRequest.RESOURCE_VIDEO_CAPTURE) need.add(Manifest.permission.CAMERA)
                        if (r == PermissionRequest.RESOURCE_AUDIO_CAPTURE) need.add(Manifest.permission.RECORD_AUDIO)
                    }
                    val missing = need.filter {
                        ContextCompat.checkSelfPermission(this@MainActivity, it) != PackageManager.PERMISSION_GRANTED
                    }
                    if (missing.isEmpty()) {
                        request.grant(request.resources)
                    } else {
                        pendingPerm = request
                        ActivityCompat.requestPermissions(this@MainActivity, missing.toTypedArray(), REQ_PERM)
                    }
                }
            }

            override fun onShowCustomView(view: View?, callback: WebChromeClient.CustomViewCallback?) {
                if (customView != null || view == null) {
                    callback?.onCustomViewHidden()
                    return
                }
                customView = view
                customCb = callback
                root.addView(view, FrameLayout.LayoutParams(-1, -1))
            }

            override fun onHideCustomView() {
                hideCustom()
            }
        }

        w.setDownloadListener { url, userAgent, contentDisposition, mimetype, _ ->
            download(url, userAgent, contentDisposition, mimetype)
        }

        views[id] = w
        root.addView(w, FrameLayout.LayoutParams(1, 1))
        applyLayout()
        return w
    }

    private fun hideCustom() {
        customView?.let { root.removeView(it) }
        customView = null
        customCb?.onCustomViewHidden()
        customCb = null
    }

    private fun download(url: String, ua: String?, cd: String?, mime: String?) {
        try {
            val r = DownloadManager.Request(Uri.parse(url))
            if (mime != null) r.setMimeType(mime)
            if (ua != null) r.addRequestHeader("User-Agent", ua)
            CookieManager.getInstance().getCookie(url)?.let { r.addRequestHeader("Cookie", it) }
            r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, URLUtil.guessFileName(url, cd, mime))
            (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(r)
            Toast.makeText(this, "بدأ التنزيل", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "تعذّر التنزيل", Toast.LENGTH_SHORT).show()
        }
    }

    // ---------- التموضع فوق منطقة الشاشة ----------
    private fun applyLayout() {
        val d = resources.displayMetrics.density
        val ok = box[2] > 1f && box[3] > 1f
        for ((id, v) in views) {
            val lp = FrameLayout.LayoutParams(Math.round(box[2] * d), Math.round(box[3] * d))
            lp.leftMargin = Math.round(box[0] * d)
            lp.topMargin = Math.round(box[1] * d)
            v.layoutParams = lp
            v.visibility = if (ok && id == activeId && !hidden) View.VISIBLE else View.GONE
        }
    }

    private fun state(id: String, v: WebView, loading: Boolean) {
        val o = JSONObject()
        o.put("url", v.url ?: "")
        o.put("title", v.title ?: "")
        o.put("loading", loading)
        o.put("back", v.canGoBack())
        o.put("fwd", v.canGoForward())
        val js = "window.__native&&window.__native.onState(${JSONObject.quote(id)},$o)"
        shell.post { shell.evaluateJavascript(js, null) }
    }

    // ---------- الإضافات ----------
    private fun m1(p0: String, url: String): Boolean {
        val p = p0.trim()
        if (p.isEmpty()) return false
        if (p == "*" || p == "<all_urls>") return true
        if (!p.contains("*") && !p.contains("://")) {
            val h = Uri.parse(url).host ?: return false
            return h == p || h.endsWith(".$p")
        }
        return try {
            Regex("^" + Regex.escape(p).replace("*", "\\E.*\\Q") + "\$", RegexOption.IGNORE_CASE).containsMatchIn(url)
        } catch (e: Exception) {
            false
        }
    }

    private fun matchesExt(o: JSONObject, url: String): Boolean =
        o.optString("match", "*").split(",").any { m1(it, url) }

    private fun vpScript(): String =
        "(function(){var m=document.querySelector('meta[name=viewport]');if(!m){m=document.createElement('meta');m.name='viewport';(document.head||document.documentElement).appendChild(m)}if(m.content!=='width=$viewportW')m.content='width=$viewportW'})()"

    private fun cssScript(url: String): String {
        val sb = StringBuilder()
        for (i in 0 until extList.length()) {
            val o = extList.optJSONObject(i) ?: continue
            if (!o.optBoolean("on", true) || !matchesExt(o, url)) continue
            sb.append(o.optString("css")).append('\n')
            val f = o.optString("filter")
            if (f.isNotBlank()) {
                sb.append("html{filter:").append(f).append("}\n")
                if (f.contains("invert")) sb.append("img,video,picture,canvas{filter:").append(f).append("}\n")
            }
        }
        if (sb.isBlank()) return ""
        return "(function(c){if(window.__dbCss===c)return;window.__dbCss=c;try{var s=new CSSStyleSheet();s.replaceSync(c);document.adoptedStyleSheets=[].concat(Array.from(document.adoptedStyleSheets),[s])}catch(e){var t=document.createElement('style');t.textContent=c;(document.head||document.documentElement).appendChild(t)}})(" +
            JSONObject.quote(sb.toString()) + ")"
    }

    private fun runExtJs(v: WebView, url: String) {
        v.evaluateJavascript(
            "(function(){if(window.__dbJs)return false;window.__dbJs=true;" +
                "window.GM_addStyle=function(c){var s=document.createElement('style');s.textContent=c;(document.head||document.documentElement).appendChild(s);return s};" +
                "window.GM_log=console.log.bind(console);return true})()"
        ) { r ->
            if (r == "true") {
                for (i in 0 until extList.length()) {
                    val o = extList.optJSONObject(i) ?: continue
                    if (!o.optBoolean("on", true) || !matchesExt(o, url)) continue
                    val js = o.optString("js")
                    if (js.isBlank()) continue
                    v.evaluateJavascript("(function(){try{\n$js\n}catch(e){console.warn('ext',e)}})();", null)
                }
            }
        }
    }

    // ---------- ملء الشاشة ----------
    private fun toggleFs() {
        isFull = !isFull
        val c = WindowInsetsControllerCompat(window, window.decorView)
        if (isFull) {
            c.hide(WindowInsetsCompat.Type.systemBars())
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        } else {
            c.show(WindowInsetsCompat.Type.systemBars())
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    // ---------- الجسر ----------
    inner class Bridge {
        @JavascriptInterface
        fun load(id: String, url: String, w: Int) {
            runOnUiThread {
                viewportW = if (w > 300) w else 1280
                val v = views[id] ?: createView(id)
                v.loadUrl(url)
            }
        }

        @JavascriptInterface
        fun back(id: String) { runOnUiThread { views[id]?.goBack() } }

        @JavascriptInterface
        fun fwd(id: String) { runOnUiThread { views[id]?.goForward() } }

        @JavascriptInterface
        fun reload(id: String) { runOnUiThread { views[id]?.reload() } }

        @JavascriptInterface
        fun close(id: String) {
            runOnUiThread {
                views.remove(id)?.let {
                    root.removeView(it)
                    it.destroy()
                }
            }
        }

        @JavascriptInterface
        fun show(id: String) { runOnUiThread { activeId = id; applyLayout() } }

        @JavascriptInterface
        fun hide(flag: Boolean) { runOnUiThread { hidden = flag; applyLayout() } }

        @JavascriptInterface
        fun rect(l: Double, t: Double, w: Double, h: Double) {
            runOnUiThread {
                box = floatArrayOf(l.toFloat(), t.toFloat(), w.toFloat(), h.toFloat())
                applyLayout()
            }
        }

        @JavascriptInterface
        fun exts(json: String) {
            extList = try { JSONArray(json) } catch (e: Exception) { JSONArray() }
        }

        @JavascriptInterface
        fun desktop(on: Boolean) {
            runOnUiThread {
                isDesk = on
                for (v in views.values) v.settings.userAgentString = ua()
            }
        }

        @JavascriptInterface
        fun fullscreen() { runOnUiThread { toggleFs() } }

        @JavascriptInterface
        fun external(url: String) {
            runOnUiThread {
                try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (e: Exception) { }
            }
        }

        @JavascriptInterface
        fun exit() { runOnUiThread { finish() } }
    }

    // ---------- نتائج النظام ----------
    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_FILE) {
            fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
            fileCb = null
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_PERM) {
            pendingPerm?.let { r ->
                val ok = grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }
                if (ok) r.grant(r.resources) else r.deny()
            }
            pendingPerm = null
        }
    }

    override fun onPause() {
        super.onPause()
        for (v in views.values) v.onPause()
    }

    override fun onResume() {
        super.onResume()
        for (v in views.values) v.onResume()
    }

    override fun onDestroy() {
        for (v in views.values) v.destroy()
        views.clear()
        shell.destroy()
        super.onDestroy()
    }
}
